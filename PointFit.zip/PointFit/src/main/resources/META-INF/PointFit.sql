INSERT INTO INGREDIENTE (idIngrediente, nombre, precioIngrediente) VALUES (DEFAULT, 'Camote', 0);
INSERT INTO INGREDIENTE (idIngrediente, nombre, precioIngrediente) VALUES (DEFAULT, 'Choclo', 0);
INSERT INTO INGREDIENTE (idIngrediente, nombre, precioIngrediente) VALUES (DEFAULT, 'Yuca Frita', 8);

INSERT INTO PLATO (idplato, nombrePlato, preciobasePlato) VALUES (DEFAULT, 'Lomo saltado', 25);
INSERT INTO PLATO (idplato, nombrePlato, preciobasePlato) VALUES (DEFAULT, 'Papa a la huancaina', 15);
INSERT INTO PLATO (idplato, nombrePlato, preciobasePlato) VALUES (DEFAULT, 'Cebiche', 15.50);
INSERT INTO PLATO (idplato, nombrePlato, preciobasePlato) VALUES (DEFAULT, 'Cau cau', 20.50);
INSERT INTO PLATO (idplato, nombrePlato, preciobasePlato) VALUES (DEFAULT, 'Arroz con pollo', 25.50);
INSERT INTO PLATO (idplato, nombrePlato, preciobasePlato) VALUES (DEFAULT, 'Tallarines rojos', 25);
INSERT INTO PLATO (idplato, nombrePlato, preciobasePlato) VALUES (DEFAULT, 'Tallarines verdes', 20.50);
INSERT INTO PLATO (idplato, nombrePlato, preciobasePlato) VALUES (DEFAULT, 'Carapulcra', 25.50);

INSERT INTO MESA (idMesa, estado) VALUES (DEFAULT, 'DISPONIBLE', 'BALCON');
INSERT INTO MESA (idMesa, estado) VALUES (DEFAULT, 'DISPONIBLE', 'BALCON');
INSERT INTO MESA (idMesa, estado) VALUES (DEFAULT, 'DISPONIBLE', 'BALCON');
INSERT INTO MESA (idMesa, estado) VALUES (DEFAULT, 'DISPONIBLE', 'ALA ESTE');
INSERT INTO MESA (idMesa, estado) VALUES (DEFAULT, 'DISPONIBLE', 'ALA ESTE');
INSERT INTO MESA (idMesa, estado) VALUES (DEFAULT, 'DISPONIBLE', 'ALA ESTE');
INSERT INTO MESA (idMesa, estado) VALUES (DEFAULT, 'DISPONIBLE', 'ALA OESTE');
INSERT INTO MESA (idMesa, estado) VALUES (DEFAULT, 'DISPONIBLE', 'ALA OESTE');
INSERT INTO MESA (idMesa, estado) VALUES (DEFAULT, 'DISPONIBLE', 'ALA OESTE');
INSERT INTO MESA (idMesa, estado) VALUES (DEFAULT, 'DISPONIBLE', 'ZONA CENTRO');
INSERT INTO MESA (idMesa, estado) VALUES (DEFAULT, 'DISPONIBLE', 'ZONA CENTRO');
INSERT INTO MESA (idMesa, estado) VALUES (DEFAULT, 'DISPONIBLE', 'ZONA CENTRO');