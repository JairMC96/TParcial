package pe.upc.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.SelectEvent;

import pe.upc.business.ClienteBusiness;
import pe.upc.business.MesaBusiness;
import pe.upc.business.MozoBusiness;
import pe.upc.business.ReservaBusiness;
import pe.upc.business.UsuarioBusiness;
import pe.upc.business.CartaBusiness;
import pe.upc.business.DetallePlatoReservaBusiness;
import pe.upc.business.IngredientesBusiness;
import pe.upc.business.PlatoBusiness;
import pe.upc.business.PlatoPersonalizadoBusiness;

import pe.upc.model.entity.Carta;
import pe.upc.model.entity.DetallePlatoReserva;
import pe.upc.model.entity.Ingrediente;
import pe.upc.model.entity.Plato;
import pe.upc.model.entity.PlatoPersonalizado;
import pe.upc.model.entity.Cliente;
import pe.upc.model.entity.Mesa;
import pe.upc.model.entity.Mozo;
import pe.upc.model.entity.Reserva;
import pe.upc.model.entity.Usuario;
import pe.upc.util.Message;

@Named
@SessionScoped
public class Controller implements Serializable{

	private static final long serialVersionUID = 1L;
	
	/* Injects */
	@Inject
	private ReservaBusiness reservaBusiness;
	
	@Inject
	private MesaBusiness mesaBusiness;
	
	@Inject
	private UsuarioBusiness usuarioBusiness;
	
	@Inject
	private ClienteBusiness clienteBusiness;
	
	@Inject
	private MozoBusiness mozoBusiness;
	
	@Inject
	private PlatoBusiness platobusiness;
	
	@Inject
	private PlatoPersonalizadoBusiness platopersonalizadobusiness;
	
	@Inject
	private IngredientesBusiness ingredientebusiness;
	
	@Inject
	private DetallePlatoReservaBusiness detalleplatoreservabusiness;
	
	@Inject
	private CartaBusiness cartabusiness;


	/*private list*/
	private Reserva reserva;
	private List<Reserva> reservas;
	private Reserva reservaSelect;
	
	private Mesa mesa;
	private List<Mesa> mesas;
	private Mesa mesaSelect;
	
	private Usuario usuario;
	private List<Usuario> usuarios;
	private Usuario usuarioSelect;
	
	private Cliente cliente;
	private List<Cliente> clientes;
	private Cliente clienteSelect;
	
	private Mozo mozo;
	private List<Mozo> mozos;
	private Mozo mozoSelect;
	
	private Plato plato;
	private List<Plato> platos;
	private Plato platoselect;
	
	private Carta carta;
	private List<Carta> cartas;
	private Carta cartaselect;
	
	private DetallePlatoReserva detalleplatoreserva;
	private List<DetallePlatoReserva> detallesplatosreservas;
	private DetallePlatoReserva detalleplatoreservaselect;
	
	private Ingrediente ingrediente;
	private List<Ingrediente> ingredientes;
	private Ingrediente ingredienteselect;
	
	private PlatoPersonalizado platopersonalizado;
	private List<PlatoPersonalizado> platospersonalizados;
	private PlatoPersonalizado platopersonalizadoselect;
	
	private String filtername;
	
	/*Post constructor*/
	@PostConstruct
	public void init() {
		/*new*/
		plato = new Plato();
		carta = new Carta();
		detalleplatoreserva = new DetallePlatoReserva();
		ingrediente = new Ingrediente();
		platopersonalizado = new PlatoPersonalizado();
		reserva = new Reserva();
		mesa = new Mesa();
		cliente = new Cliente();
		mozo = new Mozo();
		
		/*new Array*/
		platos = new ArrayList<Plato>();
		cartas = new ArrayList<Carta>();
		detallesplatosreservas = new ArrayList<DetallePlatoReserva>();
		ingredientes = new ArrayList<Ingrediente>();
		platospersonalizados = new ArrayList<PlatoPersonalizado>();
		reservas = new ArrayList<Reserva>();
		cartas = new ArrayList<Carta>();
		mesas = new ArrayList<Mesa>();
		clientes = new ArrayList<Cliente>();
		mozos = new ArrayList<Mozo>();

		/*get All*/
		getAllReservas();
		getAllClientes();
		getAllMozos();
		getAllUsuarios();
		getAllMesas();
		getAllPlatos();
		getAllCartas();
		getAllDetallesPlatosReservas();
		getAllIngredientes();
		getAllPlatoPersonalizados();
	}
	
	/*METODOS_GET ALl*/
	public void getAllReservas() {
		try {
			reservas=reservaBusiness.findAll();
		}
		catch(Exception e) {
			Message.messageError("Error al cargar reservas : " + e.getMessage());
		}
	}
	
	public void getAllClientes() {
		try {
			clientes=clienteBusiness.findAll();
		}
		catch(Exception e) {
			Message.messageError("Error al cargar clientes : " + e.getMessage());
		}
	}
	
	public void getAllMozos() {
		try {
			mozos=mozoBusiness.findAll();
		}
		catch(Exception e) {
			Message.messageError("Error al cargar mozos : " + e.getMessage());
		}
	}
	
	public void getAllMesas() {
		try {
			mesas=mesaBusiness.findAll();
		}
		catch(Exception e) {
			Message.messageError("Error al cargar mesas : " + e.getMessage());
		}
	}
	
	public void getAllUsuarios() {
		try {
			usuarios=usuarioBusiness.findAll();
		}
		catch(Exception e) {
			Message.messageError("Error al cargar usuarios : " + e.getMessage());
		}
	}
	
	public void getAllPlatos() {
		try {
			platos = platobusiness.findAll();
		}
		catch(Exception e) {
			Message.messageError("Error al cargar platos : " + e.getMessage());
		}
	}
	
	public void getAllCartas() {
		try {
			cartas = cartabusiness.findAll();
		}
		catch(Exception e) {
			Message.messageError("Error al cargar cartas : " + e.getMessage());
		}
	}
	
	public void getAllDetallesPlatosReservas() {
		try {
			detallesplatosreservas = detalleplatoreservabusiness.findAll();
		}
		catch(Exception e) {
			Message.messageError("Error al cargar los detalles de los platos : " + e.getMessage());
		}
	}
	
	public void getAllIngredientes() {
		try {
			ingredientes = ingredientebusiness.findAll();
		}
		catch(Exception e) {
			Message.messageError("Error al cargar Ingredientes : " + e.getMessage());
		}
	}
	
	public void getAllPlatoPersonalizados() {
		try {
			platospersonalizados = platopersonalizadobusiness.findAll();
		}
		catch(Exception e) {
			Message.messageError("Error al cargar plato personalizado : " + e.getMessage());
		}
	}
	
	/* --------- String New --------- */
	
	public String newPlato() {
		try {
			this.cartas=cartabusiness.getAll();
		}
		catch(Exception ex) {
			
		}
		return "insertPlato.xhtml";
	}
	
	public String newReserva(){
		try{
			this.cartas=cartabusiness.getAll();
			this.mesas=mesaBusiness.getAll();
			this.clientes=clienteBusiness.getAll();
			this.mozos=mozoBusiness.getAll();
		}
		catch(Exception ex){
			//
		}
		return "insertReserva.xhtml";
	}
	
	public String newUsuario(){
		try{
		}
		catch(Exception ex){
			//
		}
		return "insertUsuario.xhtml";
	}
	
	public String newCliente(){
		try{
			this.usuarios=usuarioBusiness.getAll();
		}
		catch(Exception ex){
			//
		}
		return "insertCliente.xhtml";
	}
	
	public String newMozo(){
		try{
			this.usuarios=usuarioBusiness.getAll();
		}
		catch(Exception ex){
			//
		}
		return "insertMozo.xhtml";
	}
	
	/* --------- String List --------- */
	
	public String listPlato() {
		return "listplato.xhtml";
	}
	
	public String listPlatoPersonalizado() {
		return "listplatopersonalizado.xhtml";
	}
	
	public String listCarta() {
		return "listcarta.xhtml";
	}
	
	public String listIngrediente() {
		return "listingrediente.xhtml";
	}

	public String listDetallePlatoReserva() {
		return "listdetalleplatoreserva.xhtml";
	}
	
	public String listReserva(){
		return "listreserva.xhtml";
	}
	
	public String listMesa(){
		return "listmesa.xhtml";
	}
	
	public String listUsuario(){
		return "listusuario.xhtml";
	}
	
	public String listCliente(){
		return "listcliente.xhtml";
	}
	
	public String listMozo(){
		return "listmozo.xhtml";
	}
	
	
	/* --------- String save --------- */
	
	public String savePlato() {
		String view = "";
		try {
			if(plato.getIdplato() != null) {
				platobusiness.update(plato);
				Message.messageInfo("Registro Actualizado Correctamente");
			}
			else {
				platobusiness.insert(plato);
				Message.messageInfo("Registro Insertado Correctamente");
			}
			this.getAllPlatos();
			resetForm();
			view = "listplato";
		}
		catch(Exception ex) {}
		return view;
	}
	
	public String savePlatoPersonalizado() {
		String view = "";
		try {
			if(platopersonalizado.getIdplatopersonalizado() != null) {
				platopersonalizado.setPlato(plato);
				platopersonalizado.setIngrediente(ingrediente);
				platopersonalizadobusiness.update(platopersonalizado);
				Message.messageInfo("Registro Actualizado Correctamente");
			}
			else {
				platopersonalizado.setPlato(plato);
				platopersonalizado.setIngrediente(ingrediente);
				platopersonalizadobusiness.insert(platopersonalizado);
				Message.messageInfo("Registro Insertado Correctamente");
			}
			this.getAllPlatoPersonalizados();
			resetForm();
			view = "listplatopersonalizado";
		}
		catch(Exception ex) {
			//Clase Utilitario
		}
		return view;
	}
	
	public String saveIngrediente(){
		String view = "";
		try {
			if(ingrediente.getIdingrediente()!=null){
				ingredientebusiness.update(ingrediente);	
				Message.messageInfo("Registro Actualizado Correctamente");
			}
			else {
				ingredientebusiness.insert(ingrediente);
				Message.messageInfo("Registro Insertado Correctamente");
			}
			this.getAllIngredientes();
			resetForm();
			view = "listingrediente";
				
		}
		catch(Exception ex){
			//Clase Utilitario
		}
		return view;
	}
	
	
	public String saveDetallePlatoReserva(){
		String view = "";
		try {
			if(detalleplatoreserva.getIddetalleplatoreserva()!=null){
				detalleplatoreserva.setPlatopersonalizado(platopersonalizado);
				detalleplatoreserva.setReserva(reserva);
				detalleplatoreservabusiness.update(detalleplatoreserva);	
				Message.messageInfo("Registro Actualizado Correctamente");
			}
			else {
				detalleplatoreserva.setPlatopersonalizado(platopersonalizado);
				detalleplatoreserva.setReserva(reserva);
				detalleplatoreservabusiness.insert(detalleplatoreserva);
				Message.messageInfo("Registro Insertado Correctamente");
			}
			this.getAllDetallesPlatosReservas();
			resetForm();
			view = "listdetalleplatoreserva";
				
		}
		catch(Exception ex){
			//Clase Utilitario
		}
		return view;
	}
	
	public String saveReserva(){
		String view = "";
		try {
			if(reserva.getIdReserva()!=null){
				reserva.setCarta(carta);
				reserva.setMesa(mesa);
				reserva.setCliente(cliente);
				reserva.setMozo(mozo);
				reservaBusiness.update(reserva);	
				Message.messageInfo("Registro Actualizado Correctamente");
			}
			else {
				reserva.setCarta(carta);
				reserva.setMesa(mesa);
				reserva.setCliente(cliente);
				reserva.setMozo(mozo);
				reservaBusiness.insert(reserva);
				Message.messageInfo("Registro Insertado Correctamente");
			}
			this.getAllReservas();
			resetForm();
			view = "listreserva";
				
		}
		catch(Exception ex){
			//Clase Utilitario
		}
		return view;
	}
	
	public String saveCarta() {
		String view = "";
		try {
			if(carta.getIdcarta() != null) {
				carta.setPlato(plato);
				cartabusiness.update(carta);
				Message.messageInfo("Registro Actualizado Correctamente");
			}
			else {
				carta.setPlato(plato);
				cartabusiness.insert(carta);
				Message.messageInfo("Registro Insertado Correctamente");
			}
			this.getAllCartas();
			resetForm();
			view = "listcarta";
		}
		catch(Exception ex) {
			//Clase Utilitario
		}
		return view;
	}
	
	public String saveCliente() {
		String view = "";
		try {
			if(cliente.getIdCliente() != null) {
				cliente.setUsuario(usuario);
				clienteBusiness.update(cliente);
				Message.messageInfo("Registro Actualizado Correctamente");
			}
			else {
				cliente.setUsuario(usuario);
				clienteBusiness.insert(cliente);
				Message.messageInfo("Registro Insertado Correctamente");
			}
			this.getAllClientes();
			resetForm();
			view = "listcliente";
		}
		catch(Exception ex) {
			//Clase Utilitario
		}
		return view;
	}
	
	public String saveMozo() {
		String view = "";
		try {
			if(mozo.getIdMozo() != null) {
				mozo.setUsuario(usuario);
				mozoBusiness.update(mozo);
				Message.messageInfo("Registro Actualizado Correctamente");
			}
			else {
				mozo.setUsuario(usuario);
				mozoBusiness.insert(mozo);
				Message.messageInfo("Registro Insertado Correctamente");
			}
			this.getAllMozos();
			resetForm();
			view = "listmozo";
		}
		catch(Exception ex) {
			//Clase Utilitario
		}
		return view;
	}

	public String saveUsuario() {
		String view = "";
		try {
			if(usuario.getIdUsuario() != null) {
				usuarioBusiness.update(usuario);
				Message.messageInfo("Registro Actualizado Correctamente");
			}
			else {
				usuarioBusiness.insert(usuario);
				Message.messageInfo("Registro Insertado Correctamente");
			}
			this.getAllUsuarios();
			resetForm();
			view = "listusuario";
		}
		catch(Exception ex) {
			//Clase Utilitario
		}
		return view;
	}
	
	public String saveMesa() {
		String view = "";
		try {
			if(mesa.getIdMesa() != null) {
				mesaBusiness.update(mesa);
				Message.messageInfo("Registro Actualizado Correctamente");
			}
			else {
				mesaBusiness.insert(mesa);
				Message.messageInfo("Registro Insertado Correctamente");
			}
			this.getAllMesas();
			resetForm();
			view = "listmesa";
		}
		catch(Exception ex) {
			//Clase Utilitario
		}
		return view;
	}
	
	/* --------- String edit --------- */
	public String editPlato() {
		String view = "";
		try {
			if (this.platoselect != null) {
				this.plato = platoselect;
				view = "plato/update";
			}
			else {
				Message.messageError("Debe seleccionar un plato");
			}
		}
		catch(Exception ex) {
			Message.messageError("Error en plato seleccionado: " + ex.getMessage());
		}
		return view;
	}
	
	public String editReserva(){
		String view = "";
		try{
			if (this.reservaSelect != null) {
				this.reserva = reservaSelect;
				view = "reserva/update";
			}
			else {
				Message.messageError("Debe seleccionar una reserva");
			}
		}
		catch(Exception ex){
			Message.messageError("Error en reserva seleccionada: " + ex.getMessage());
		}
		return view;
	}
	
	public String editCliente(){
		String view = "";
		try{
			if (this.clienteSelect != null) {
				this.cliente = clienteSelect;
				view = "cliente/update";
			}
			else {
				Message.messageError("Debe seleccionar un cliente");
			}
		}
		catch(Exception ex){
			Message.messageError("Error en cliente seleccionado: " + ex.getMessage());
		}
		return view;
	}
	
	public String editMozo(){
		String view = "";
		try{
			if (this.mozoSelect != null) {
				this.mozo = mozoSelect;
				view = "mozo/update";
			}
			else {
				Message.messageError("Debe seleccionar un mozo");
			}
		}
		catch(Exception ex){
			Message.messageError("Error en mozo seleccionado: " + ex.getMessage());
		}
		return view;
	}
	
	public String editUsuario(){
		String view = "";
		try{
			if (this.usuarioSelect != null) {
				this.usuario = usuarioSelect;
				view = "usuario/update";
			}
			else {
				Message.messageError("Debe seleccionar un usuario");
			}
		}
		catch(Exception ex){
			Message.messageError("Error en usuario seleccionado: " + ex.getMessage());
		}
		return view;
	}
	
	public String editCarta(){
		String view = "";
		try{
			if (this.cartaselect != null) {
				this.carta = cartaselect;
				view = "carta/update";
			}
			else {
				Message.messageError("Debe seleccionar un carta");
			}
		}
		catch(Exception ex){
			Message.messageError("Error en carta seleccionado: " + ex.getMessage());
		}
		return view;
	}
	
	public String editPlatoPersonalizado(){
		String view = "";
		try{
			if (this.platopersonalizadoselect != null) {
				this.platopersonalizado = platopersonalizadoselect;
				view = "platopersonalizado/update";
			}
			else {
				Message.messageError("Debe seleccionar un platopersonalizado");
			}
		}
		catch(Exception ex){
			Message.messageError("Error en platopersonalizado seleccionado: " + ex.getMessage());
		}
		return view;
	}
	
	public String editDetallePlatoReserva(){
		String view = "";
		try{
			if (this.detalleplatoreservaselect != null) {
				this.detalleplatoreserva = detalleplatoreservaselect;
				view = "detalleplatoreserva/update";
			}
			else {
				Message.messageError("Debe seleccionar un detalleplatoreserva");
			}
		}
		catch(Exception ex){
			Message.messageError("Error en detalleplatoreserva seleccionado: " + ex.getMessage());
		}
		return view;
	}
	
	public String editIngrediente(){
		String view = "";
		try{
			if (this.ingredienteselect != null) {
				this.ingrediente = ingredienteselect;
				view = "ingrediente/update";
			}
			else {
				Message.messageError("Debe seleccionar un ingrediente");
			}
		}
		catch(Exception ex){
			Message.messageError("Error en ingrediente seleccionado: " + ex.getMessage());
		}
		return view;
	}
	
	public String editMesa(){
		String view = "";
		try{
			if (this.mesaSelect != null) {
				this.mesa = mesaSelect;
				view = "mesa/update";
			}
			else {
				Message.messageError("Debe seleccionar un mesa");
			}
		}
		catch(Exception ex){
			Message.messageError("Error en mesa seleccionado: " + ex.getMessage());
		}
		return view;
	}

	
	/* --------- String delete --------- */
	public String deletePlato() {
		String view = "";
		try {		
			this.plato = platoselect;
			platobusiness.delete(this.plato);
			Message.messageInfo("Registro Eliminado Correctamente");
			this.getAllPlatos();
			view = "listplato";
		}
		catch(Exception ex) {
			Message.messageError("Error en Plato Seleccionado: " + ex.getMessage());
		}
		return view;	
	}
	
	public String deleteReserva() {
		
		String view = "";
		try{
			this.reserva = reservaSelect;
			reservaBusiness.delete(this.reserva);
			Message.messageInfo("Registro Eliminado Correctamente");
			this.getAllReservas();
			view = "listreserva";
		}
		catch(Exception ex){
			Message.messageError("Error en Reserva : " + ex.getMessage());
		}
		return view;
	}
	
	public String deleteCarta() {
		
		String view = "";
		try{
			this.carta = cartaselect;
			cartabusiness.delete(this.carta);
			Message.messageInfo("Registro Eliminado Correctamente");
			this.getAllCartas();
			view = "listcarta";
		}
		catch(Exception ex){
			Message.messageError("Error en Carta : " + ex.getMessage());
		}
		return view;
	}
	
	public String deleteCliente() {
		
		String view = "";
		try{
			this.cliente = clienteSelect;
			clienteBusiness.delete(this.cliente);
			Message.messageInfo("Registro Eliminado Correctamente");
			this.getAllClientes();
			view = "listcliente";
		}
		catch(Exception ex){
			Message.messageError("Error en Cliente : " + ex.getMessage());
		}
		return view;
	}
	
	public String deleteDetallePlatoReserva() {
		
		String view = "";
		try{
			this.detalleplatoreserva = detalleplatoreservaselect;
			detalleplatoreservabusiness.delete(this.detalleplatoreserva);
			Message.messageInfo("Registro Eliminado Correctamente");
			this.getAllDetallesPlatosReservas();
			view = "listdetalleplatoreserva";
		}
		catch(Exception ex){
			Message.messageError("Error en DetallePlatoReserva : " + ex.getMessage());
		}
		return view;
	}
	
	public String deleteIngrediente() {
		
		String view = "";
		try{
			this.ingrediente = ingredienteselect;
			ingredientebusiness.delete(this.ingrediente);
			Message.messageInfo("Registro Eliminado Correctamente");
			this.getAllIngredientes();
			view = "listingrediente";
		}
		catch(Exception ex){
			Message.messageError("Error en Ingrediente : " + ex.getMessage());
		}
		return view;
	}

	public String deleteMesa() {
		
		String view = "";
		try{
			this.mesa = mesaSelect;
			mesaBusiness.delete(this.mesa);
			Message.messageInfo("Registro Eliminado Correctamente");
			this.getAllMesas();
			view = "listmesa";
		}
		catch(Exception ex){
			Message.messageError("Error en Mesa : " + ex.getMessage());
		}
		return view;
	}
	
	public String deleteMozo() {
		
		String view = "";
		try{
			this.mozo = mozoSelect;
			mozoBusiness.delete(this.mozo);
			Message.messageInfo("Registro Eliminado Correctamente");
			this.getAllMozos();
			view = "listmozo";
		}
		catch(Exception ex){
			Message.messageError("Error en Mozo : " + ex.getMessage());
		}
		return view;
	}
	
	public String deleteUsuario() {
		
		String view = "";
		try{
			this.usuario = usuarioSelect;
			usuarioBusiness.delete(this.usuario);
			Message.messageInfo("Registro Eliminado Correctamente");
			this.getAllUsuarios();
			view = "listusuario";
		}
		catch(Exception ex){
			Message.messageError("Error en Usuario : " + ex.getMessage());
		}
		return view;
	}
	
	public String deletePlatoPersonalizado() {
		
		String view = "";
		try{
			this.platopersonalizado = platopersonalizadoselect;
			platopersonalizadobusiness.delete(this.platopersonalizado);
			Message.messageInfo("Registro Eliminado Correctamente");
			this.getAllPlatoPersonalizados();
			view = "listplatopersonalizado";
		}
		catch(Exception ex){
			Message.messageError("Error en PlatoPersonalizado : " + ex.getMessage());
		}
		return view;
	}
	
	/* --------- String resetForm --------- */
	public void resetForm() {
		this.filtername = "";
		this.plato = new Plato();
		this.carta = new Carta();
		this.cliente = new Cliente();
		this.detalleplatoreserva = new DetallePlatoReserva();
		this.ingrediente = new Ingrediente();
		this.mesa = new Mesa();
		this.platopersonalizado = new PlatoPersonalizado();
		this.reserva = new Reserva();
		this.usuario = new Usuario();
	}
	
	/* --------- String Search --------- */
	public void searchPlatoByName() {
		try {
			platos = platobusiness.findByName(this.filtername.trim());
			resetForm();
			if (platos.isEmpty()) {
				Message.messageInfo("No se encontraron platos");
			}
		}
		catch(Exception ex) {
			Message.messageError("Error al buscar Plato: " + ex.getMessage());
		}		
	}
	
	public void searchUsuarioByName() {
		try {
			usuarios = usuarioBusiness.findByNombre(this.filtername.trim());
			resetForm();
			if (usuarios.isEmpty()) {
				Message.messageInfo("No se encontraron usuarios");
			}
		}
		catch(Exception ex) {
			Message.messageError("Error al buscar Usuario: " + ex.getMessage());
		}		
	}
	
	public void searchClienteByName() {
		try {
			clientes = clienteBusiness.findByName(this.filtername.trim());
			resetForm();
			if (clientes.isEmpty()) {
				Message.messageInfo("No se encontraron clientes");
			}
		}
		catch(Exception ex) {
			Message.messageError("Error al buscar Cliente: " + ex.getMessage());
		}		
	}
	
	public void searchDetallePlatoReservaByName() {
		try {
			detallesplatosreservas = detalleplatoreservabusiness.findByName(this.filtername.trim());
			resetForm();
			if (detallesplatosreservas.isEmpty()) {
				Message.messageInfo("No se encontraron detalles de la reserva");
			}
		}
		catch(Exception ex) {
			Message.messageError("Error al buscar  detalles de la reserva: " + ex.getMessage());
		}		
	}
	
	public void searchIngredienteByName() {
		try {
			ingredientes = ingredientebusiness.findByName(this.filtername.trim());
			resetForm();
			if (ingredientes.isEmpty()) {
				Message.messageInfo("No se encontraron ingredientes");
			}
		}
		catch(Exception ex) {
			Message.messageError("Error al buscar Ingrediente: " + ex.getMessage());
		}		
	}
	
	public void searchMesaByName() {
		try {
			mesas = mesaBusiness.findByEstado(this.filtername.trim());
			resetForm();
			if (mesas.isEmpty()) {
				Message.messageInfo("No se encontraron mesas");
			}
		}
		catch(Exception ex) {
			Message.messageError("Error al buscar Mesa: " + ex.getMessage());
		}		
	}
	
	public void searchMozoByName() {
		try {
			mozos = mozoBusiness.findByName(this.filtername.trim());
			resetForm();
			if (mozos.isEmpty()) {
				Message.messageInfo("No se encontraron mozos");
			}
		}
		catch(Exception ex) {
			Message.messageError("Error al buscar Mozo: " + ex.getMessage());
		}		
	}
	
	public void searchPlatoPersonalizadoByName() {
		try {
			platospersonalizados = platopersonalizadobusiness.findByName(this.filtername.trim());
			resetForm();
			if (platospersonalizados.isEmpty()) {
				Message.messageInfo("No se encontraron platos personalizados");
			}
		}
		catch(Exception ex) {
			Message.messageError("Error al buscar Platos Personalizados: " + ex.getMessage());
		}		
	}
	
	public void searchCartaByPlatoName() {
		try {
			cartas = cartabusiness.findByName(this.filtername.trim());
			resetForm();
			if (cartas.isEmpty()) {
				Message.messageInfo("No se encontraron cartas");
			}
		}
		catch(Exception ex) {
			Message.messageError("Error al buscar Carta: " + ex.getMessage());
		}		
	}

/*Busca a Reserva por Cliente - Corregir en Repository si es que est� mal*/
	public void searchReservaByName(){
		try {
			reservas = reservaBusiness.findByName(this.filtername.trim());
			resetForm();
			if (reservas.isEmpty()){
				Message.messageInfo("No se encontraron reservas para este cliente");
			}
		}
		catch(Exception ex){
			Message.messageError("Error al buscar Reserva: " + ex.getMessage());
		}
	}
	
	/* --------- void Select --------- */
	public void selectPlato(SelectEvent e) {
		this.platoselect = (Plato)e.getObject();
	}
	
	public void selectReserva(SelectEvent e){
		this.reservaSelect = (Reserva)e.getObject();
	}
	
	public void selectCarta(SelectEvent e){
		this.cartaselect = (Carta)e.getObject();
	}
	
	public void selectCliente(SelectEvent e){
		this.clienteSelect = (Cliente)e.getObject();
	}
	
	public void selectDetallePlatoReserva(SelectEvent e){
		this.detalleplatoreservaselect = (DetallePlatoReserva)e.getObject();
	}
	
	public void selectIngrediente(SelectEvent e){
		this.ingredienteselect = (Ingrediente)e.getObject();
	}
	
	public void selectMesa(SelectEvent e){
		this.mesaSelect = (Mesa)e.getObject();
	}
	
	public void selectMozo(SelectEvent e){
		this.mozoSelect = (Mozo)e.getObject();
	}
	
	public void selectPlatoPersonalizado(SelectEvent e){
		this.platopersonalizadoselect = (PlatoPersonalizado)e.getObject();
	}
	
	public void selectUsuario(SelectEvent e){
		this.usuarioSelect = (Usuario)e.getObject();
	}

	public Reserva getReserva() {
		return reserva;
	}

	public void setReserva(Reserva reserva) {
		this.reserva = reserva;
	}

	public List<Reserva> getReservas() {
		return reservas;
	}

	public void setReservas(List<Reserva> reservas) {
		this.reservas = reservas;
	}

	public Reserva getReservaSelect() {
		return reservaSelect;
	}

	public void setReservaSelect(Reserva reservaSelect) {
		this.reservaSelect = reservaSelect;
	}

	public Mesa getMesa() {
		return mesa;
	}

	public void setMesa(Mesa mesa) {
		this.mesa = mesa;
	}

	public List<Mesa> getMesas() {
		return mesas;
	}

	public void setMesas(List<Mesa> mesas) {
		this.mesas = mesas;
	}

	public Mesa getMesaSelect() {
		return mesaSelect;
	}

	public void setMesaSelect(Mesa mesaSelect) {
		this.mesaSelect = mesaSelect;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public List<Usuario> getUsuarios() {
		return usuarios;
	}

	public void setUsuarios(List<Usuario> usuarios) {
		this.usuarios = usuarios;
	}

	public Usuario getUsuarioSelect() {
		return usuarioSelect;
	}

	public void setUsuarioSelect(Usuario usuarioSelect) {
		this.usuarioSelect = usuarioSelect;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public List<Cliente> getClientes() {
		return clientes;
	}

	public void setClientes(List<Cliente> clientes) {
		this.clientes = clientes;
	}

	public Cliente getClienteSelect() {
		return clienteSelect;
	}

	public void setClienteSelect(Cliente clienteSelect) {
		this.clienteSelect = clienteSelect;
	}

	public Mozo getMozo() {
		return mozo;
	}

	public void setMozo(Mozo mozo) {
		this.mozo = mozo;
	}

	public List<Mozo> getMozos() {
		return mozos;
	}

	public void setMozos(List<Mozo> mozos) {
		this.mozos = mozos;
	}

	public Mozo getMozoSelect() {
		return mozoSelect;
	}

	public void setMozoSelect(Mozo mozoSelect) {
		this.mozoSelect = mozoSelect;
	}

	public Plato getPlato() {
		return plato;
	}

	public void setPlato(Plato plato) {
		this.plato = plato;
	}

	public List<Plato> getPlatos() {
		return platos;
	}

	public void setPlatos(List<Plato> platos) {
		this.platos = platos;
	}

	public Plato getPlatoselect() {
		return platoselect;
	}

	public void setPlatoselect(Plato platoselect) {
		this.platoselect = platoselect;
	}

	public Carta getCarta() {
		return carta;
	}

	public void setCarta(Carta carta) {
		this.carta = carta;
	}

	public List<Carta> getCartas() {
		return cartas;
	}

	public void setCartas(List<Carta> cartas) {
		this.cartas = cartas;
	}

	public Carta getCartaselect() {
		return cartaselect;
	}

	public void setCartaselect(Carta cartaselect) {
		this.cartaselect = cartaselect;
	}

	public DetallePlatoReserva getDetalleplatoreserva() {
		return detalleplatoreserva;
	}

	public void setDetalleplatoreserva(DetallePlatoReserva detalleplatoreserva) {
		this.detalleplatoreserva = detalleplatoreserva;
	}

	public List<DetallePlatoReserva> getDetallesplatosreservas() {
		return detallesplatosreservas;
	}

	public void setDetallesplatosreservas(List<DetallePlatoReserva> detallesplatosreservas) {
		this.detallesplatosreservas = detallesplatosreservas;
	}

	public DetallePlatoReserva getDetalleplatoreservaselect() {
		return detalleplatoreservaselect;
	}

	public void setDetalleplatoreservaselect(DetallePlatoReserva detalleplatoreservaselect) {
		this.detalleplatoreservaselect = detalleplatoreservaselect;
	}

	public Ingrediente getIngrediente() {
		return ingrediente;
	}

	public void setIngrediente(Ingrediente ingrediente) {
		this.ingrediente = ingrediente;
	}

	public List<Ingrediente> getIngredientes() {
		return ingredientes;
	}

	public void setIngredientes(List<Ingrediente> ingredientes) {
		this.ingredientes = ingredientes;
	}

	public Ingrediente getIngredienteselect() {
		return ingredienteselect;
	}

	public void setIngredienteselect(Ingrediente ingredienteselect) {
		this.ingredienteselect = ingredienteselect;
	}

	public PlatoPersonalizado getPlatopersonalizado() {
		return platopersonalizado;
	}

	public void setPlatopersonalizado(PlatoPersonalizado platopersonalizado) {
		this.platopersonalizado = platopersonalizado;
	}

	public List<PlatoPersonalizado> getPlatospersonalizados() {
		return platospersonalizados;
	}

	public void setPlatospersonalizados(List<PlatoPersonalizado> platospersonalizados) {
		this.platospersonalizados = platospersonalizados;
	}

	public PlatoPersonalizado getPlatopersonalizadoselect() {
		return platopersonalizadoselect;
	}

	public void setPlatopersonalizadoselect(PlatoPersonalizado platopersonalizadoselect) {
		this.platopersonalizadoselect = platopersonalizadoselect;
	}

	public String getFiltername() {
		return filtername;
	}

	public void setFiltername(String filtername) {
		this.filtername = filtername;
	}

}


















