package pe.upc.model.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ingredientes")
public class Ingrediente {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long idingrediente;
	
	private String nombreingrediente;
	
	private double precioingrediente;
	
	public Long getIdingrediente() {
		return idingrediente;
	}

	public void setIdingrediente(Long idingrediente) {
		this.idingrediente = idingrediente;
	}

	public String getNombreingrediente() {
		return nombreingrediente;
	}

	public void setNombreingrediente(String nombreingrediente) {
		this.nombreingrediente = nombreingrediente;
	}

	public double getPrecioingrediente() {
		return precioingrediente;
	}

	public void setPrecioingrediente(double precioingrediente) {
		this.precioingrediente = precioingrediente;
	}

}
