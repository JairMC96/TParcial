package pe.upc.model.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table; 

@Entity
@Table(name = "platos")
public class Plato {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long idplato;
	
	private String nombreplato;
	
	private double preciobaseplato;
	
	@ManyToOne
	@JoinColumn(name = "idcarta", nullable = false) 
	private Carta carta;

	public Long getIdplato() {
		return idplato;
	}

	public void setIdplato(Long idplato) {
		this.idplato = idplato;
	}

	public String getNombreplato() {
		return nombreplato;
	}

	public void setNombreplato(String nombreplato) {
		this.nombreplato = nombreplato;
	}

	public double getPreciobaseplato() {
		return preciobaseplato;
	}

	public void setPreciobaseplato(double preciobaseplato) {
		this.preciobaseplato = preciobaseplato;
	}

	public Carta getCarta() {
		return carta;
	}

	public void setCarta(Carta carta) {
		this.carta = carta;
	}
	
	
}