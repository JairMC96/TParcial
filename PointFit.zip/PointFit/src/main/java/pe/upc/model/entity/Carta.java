package pe.upc.model.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "carta")
public class Carta {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long idcarta;
	
	private Date fechacarta;
	
	@ManyToOne
	@JoinColumn(name="idplato", nullable=false)
	private Plato plato;

	public Long getIdcarta() {
		return idcarta;
	}

	public void setIdcarta(Long idcarta) {
		this.idcarta = idcarta;
	}

	public Date getFechacarta() {
		return fechacarta;
	}

	public void setFechacarta(Date fechacarta) {
		this.fechacarta = fechacarta;
	}

	public Plato getPlato() {
		return plato;
	}

	public void setPlato(Plato plato) {
		this.plato = plato;
	}
	
}