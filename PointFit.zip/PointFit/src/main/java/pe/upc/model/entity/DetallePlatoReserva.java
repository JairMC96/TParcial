package pe.upc.model.entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

public class DetallePlatoReserva {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long iddetalleplatoreserva;
	
	@ManyToOne
	@JoinColumn(name="idreserva", nullable=false)
	private Reserva reserva;
	
	@ManyToOne
	@JoinColumn(name="idPlatopersonalizado", nullable=false)
	private PlatoPersonalizado platopersonalizado;
	
	private double precioplato;

	public Long getIddetalleplatoreserva() {
		return iddetalleplatoreserva;
	}

	public void setIddetalleplatoreserva(Long iddetalleplatoreserva) {
		this.iddetalleplatoreserva = iddetalleplatoreserva;
	}

	public Reserva getReserva() {
		return reserva;
	}

	public void setReserva(Reserva reserva) {
		this.reserva = reserva;
	}

	public PlatoPersonalizado getPlatopersonalizado() {
		return platopersonalizado;
	}

	public void setPlatopersonalizado(PlatoPersonalizado platopersonalizado) {
		this.platopersonalizado = platopersonalizado;
	}

	public double getPrecioplato() {
		return precioplato;
	}

	public void setPrecioplato(double precioplato) {
		this.precioplato = precioplato;
	}

}
