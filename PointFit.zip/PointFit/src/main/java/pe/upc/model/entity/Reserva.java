package pe.upc.model.entity;

import java.sql.Time;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Reserva")
public class Reserva {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long idReserva;
	
	@OneToOne
	@JoinColumn(name="idCarta", nullable=false)
	private Carta carta;
	
	@OneToOne
	@JoinColumn(name="idMesa", nullable=false)
	private Mesa mesa;
	
	private int sillas;
	
	@OneToOne
	@JoinColumn(name="idCliente", nullable=false)
	private Cliente cliente;
	
	@OneToOne
	@JoinColumn(name="idMozo", nullable=false)
	private Mozo mozo;
	
	private Date FechaReserva;
	
	private Time HoraReserva;
	
	private double MontoTotal;

	public Long getIdReserva() {
		return idReserva;
	}

	public void setIdReserva(Long idReserva) {
		this.idReserva = idReserva;
	}

	public Carta getCarta() {
		return carta;
	}

	public void setCarta(Carta carta) {
		this.carta = carta;
	}

	public Mesa getMesa() {
		return mesa;
	}

	public void setMesa(Mesa mesa) {
		this.mesa = mesa;
	}

	public int getSillas() {
		return sillas;
	}

	public void setSillas(int sillas) {
		this.sillas = sillas;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Mozo getMozo() {
		return mozo;
	}

	public void setMozo(Mozo mozo) {
		this.mozo = mozo;
	}

	public Date getFechaReserva() {
		return FechaReserva;
	}

	public void setFechaReserva(Date fechaReserva) {
		FechaReserva = fechaReserva;
	}

	public Time getHoraReserva() {
		return HoraReserva;
	}

	public void setHoraReserva(Time horaReserva) {
		HoraReserva = horaReserva;
	}

	public double getMontoTotal() {
		return MontoTotal;
	}

	public void setMontoTotal(double montoTotal) {
		MontoTotal = montoTotal;
	}
	
	
}
