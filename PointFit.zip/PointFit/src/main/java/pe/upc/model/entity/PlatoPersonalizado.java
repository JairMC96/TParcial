package pe.upc.model.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="PlatoPersonalizado")
public class PlatoPersonalizado {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long idplatopersonalizado;
	
	private double precioplato;
	
	@OneToOne
	@JoinColumn(name="idplato", nullable=false)
	private Plato plato;
	
	private Long idingrediente;
	
	@ManyToOne
	@JoinColumn(name="idingrediente", nullable=false)
	private Ingrediente ingrediente;

	public Long getIdplatopersonalizado() {
		return idplatopersonalizado;
	}

	public void setIdplatopersonalizado(Long idplatopersonalizado) {
		this.idplatopersonalizado = idplatopersonalizado;
	}

	public double getPrecioplato() {
		return precioplato;
	}

	public void setPrecioplato(double precioplato) {
		this.precioplato = precioplato;
	}

	public Plato getPlato() {
		return plato;
	}

	public void setPlato(Plato plato) {
		this.plato = plato;
	}

	public Long getIdingrediente() {
		return idingrediente;
	}

	public void setIdingrediente(Long idingrediente) {
		this.idingrediente = idingrediente;
	}

	public Ingrediente getIngrediente() {
		return ingrediente;
	}

	public void setIngrediente(Ingrediente ingrediente) {
		this.ingrediente = ingrediente;
	}

}
